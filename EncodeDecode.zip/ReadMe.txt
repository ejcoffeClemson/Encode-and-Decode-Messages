Encoding and Decoding Messages Project

Description: This project deals Encoding and Decoding String Messages with the use of Queues and a Key that is used to customize the encoding and decoding of a message.

How to Run: This program has at its disposal a makefile to help run the program,
	    In the terminal first type make and hit enter to compile the program,
            Afterwards, type make run into the terminal to run the program. 
